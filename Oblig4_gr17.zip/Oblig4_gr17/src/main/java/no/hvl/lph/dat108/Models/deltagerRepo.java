package no.hvl.lph.dat108.Models;

import org.springframework.data.jpa.repository.JpaRepository;

public interface deltagerRepo extends JpaRepository<Deltager,Integer> {

}
