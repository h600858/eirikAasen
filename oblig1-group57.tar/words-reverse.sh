#!/bin/bash
##opprette et temporary directory 
## -d er en istruskjon som forteller at vi skal opprette directoriet
##alle x-ene blir erstattet av tilfeldige karakterer
temporary=$(mktemp -d -t ci-XXXXXXXXXX)

StrInput=`cat`
##hvis det er igen argument
if [ $# -eq 0 ]
then
##piper inputten gjennom sh filene
echo "$StrInput" | ./depunctuate.sh $temporary | ./words-reverse-ll | ./repunctuate.sh $temporary
##hvis vi bruker bypass som argument
elif [ $1 == "--bypass" ]
then
    echo "$StrInput" | ./depunctuate.sh $temporary | ./repunctuate.sh $temporary
else
    echo Error: ugyldig commandline argument er gitt 1>&2
    exit 1
    ##exit 1 skrur av programmet
fi



