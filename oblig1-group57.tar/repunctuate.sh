#!/bin/bash
##directory hvor eg søker etter lookup filene
DIRECTORY="$1"
##standard input
StrInput=`cat`
echo "$StrInput" > "$1/Punctuated.txt"
##bruker lookupfilene til å bytte tilbake til orginal punktuation
##hvis currentline er 
while read -r CURRENT_LINE
do
    
    
        if [[ -f $1/"$CURRENT_LINE".txt ]]
        then #hvis hash filen eksisterer, leser den innholdet i filen
             #setter dette inn i en variabel streng 
            temporary=$(cat "$1/$CURRENT_LINE".txt)
            Streng+="$temporary"
        else
            Streng+="$CURRENT_LINE"

        fi

done <$1/"Punctuated".txt 

    #oversetter til slutt med å fjerne '|' og gjere dei om til newline
Finito=${String//"|"/"\n"}
echo -e $Finito
rm $1/Punctuated.txt

