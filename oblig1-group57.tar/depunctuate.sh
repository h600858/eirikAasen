#!/bin/bash
##tar et coomandline argument som seier i hvilke directory vi skal lagre data
#Directory eg har alle filene mine
DIRECTORY="$1"
#standard input fra bruker
StrInput=`cat`
#legger inputten inn i en fil 
echo "$StrInput " > $1/Input.txt

#oversetter linjeskift til | 
tr '\n' '|' < $1/Input.txt > $1/enkeltLineOversatt.txt
#oversetter alt som ikkj er numersik til linjeskift inkl det tegnet er, gjer det globally
sed -E 's/[^[:alnum:]]+/\n&\n/g' < $1/enkeltLineOversatt.txt > $1/Oversatt_fullført.txt


##skriptet skal sjekke om en lookupfil allerede eksisterer

while IFS="" read -r CURRENT_LINE
do
    if [[ ! $CURRENT_LINE =~ [[:alnum:]] ]]
    then
        HASHED="$(echo -n "$CURRENT_LINE" | sha256sum | head -c 64)"
        if [[ -f $1/$HASHED.txt ]]
            then
            #hvis innholdet i den hashede filen ikkje stemmer overens blir den overskrevet
            if ! grep -q "$CURRENT_LINE" "$1/$HASHED".txt
            then
                echo "$CURRENT_LINE" > $1/$HASHED.txt
            fi
    
        else
        #om fila ikkje eksistera
            echo "$CURRENT_LINE" > $1/"$HASHED".txt
        fi
        echo $HASHED 
    else
        echo $CURRENT_LINE 
    fi

done <$1/Oversatt_fullført.txt

#om den allerede eksisterer skal scriptet sjekke om den inneholder
#riktig tegn'
rm $1/Input.txt
rm $1/enkeltLineOversatt.txt
rm $1/Oversatt_fullført.txt




