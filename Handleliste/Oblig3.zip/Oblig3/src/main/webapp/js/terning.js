/**
 * 
 */
 class Dice{
	#value
	
	Constructor(value){
		this.#value = value;
		
	}
	
	roll(){
		let a = Math.floor(Math.random() *6)+1;
		this.#value = a;
		
	}
	
	get getValue(){
		return this.#value;
	}
	
	set setValue(a){
		this.#value = a;
	}
}
//knytter terningen til HTML koden
class DiceController {
	value;
	
	
	Constructor(root){
		this.rootElement = root
		this.value =0;
		
		const rootElement = new DiceController("root");
		new DiceController(rootElement);
		//css-selektor for å kage en referanse til elementet med attributt data-dicebutton
		const dicebutton = rootElement.querySelector("*[data-dicebutton]");
		let dice = document.getElementById("myspan");
		//metode for å trille terningen mot klikk på knappen
		dicebutton.addEventListener("click",this.#rollDice.bind(this));
		//resultatet postes på skjermen
		dice.innerText = Dice.getValue();
		console.log(this.value);
	}
	#rollDice(){
		let dice1 = new Dice(0);
		dice1.roll();
		this.value = dice1.getValue();
		let dicecontroller = document.getElementById("myspan");
		dicecontroller.innerText = this.value;
	}
	
}
document.addEventListener("DOMContentLoaded", init);